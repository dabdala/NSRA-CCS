#!/bin/bash

#
# Este archivo debe colocarse en la raiz de la instalaci�n, modificando los nombres
# de broker por los nombres que se est�n utilizando en la instalaci�n.
#
brokertype="webspeed"
brokers="wsnsra_servicios wsnsra_html"
ganimedepath="/opt/ganimede/bin"
proenvpath="/opt/oe102b/bin"

if [[ $# -eq 0 ]] ; then
  echo 'Debe especificar la acci�n a realizar: start | stop | restart | clean | query'
  exit 1
fi

case "$1" in
  query) echo 'Consultando estado de los brokers..'
    ;;
  clean) echo 'Limpiando directorios de trabajo..'
    ;;
  restart) echo 'Reiniciando brokers..'
    ;;
  stop) echo 'Deteniendo brokers..'
    ;;
  start) echo 'Iniciando brokers..'
    ;;
  *) echo 'Las acciones v�lidas son:'
    echo '  start: inicia los brokers definidos.'
    echo '  stop: detiene los brokers definidos.'
    echo '  restart: equivalente a especificar stop, luego clean y por �ltimo start.'
    echo '  clean: limpia los directorios de trabajo.'
    echo '  query: consulta el estado de los brokers.'
    exit 1
    ;;
esac 
 
directorio=`pwd`
. "$proenvpath"/proenv

for broker in $brokers
do
	if [ $1 == "query" ]; then
	 if [ $brokertype == "webspeed" ]; then
		wtbman -query -i "$broker"
	 else
	  "$ganimedepath"/gnm_adm status "$broker"
	 fi
	fi
	if [ $1 == "stop" ] || [ $1 == "restart" ]; then
   if [ $brokertype == "webspeed" ]; then
		wtbman -stop -i "$broker"
	 else
	  "$ganimedepath"/gnm_adm stop "$broker"
	 fi
	fi
done
if [ $1 == "clean" ] || [ $1 == "restart" ]; then
	rm -f $directorio/nsra/servicios/log/*.log
	rm -f $directorio/nsra/servicios/inout/*.in
	rm -f $directorio/nsra/servicios/inout/*.out
	rm -f $directorio/nsra/servicios/inout/*.inout
	rm -f $directorio/nsra/servicios/background/*.bsg
	rm -f $directorio/nsra/servicios/background/*.bsp
	rm -f $directorio/protrace.*
fi
if [ $1 == "start" ] || [ $1 == "restart" ]; then
  if [ $brokertype == "webspeed" ]; then
	 for broker in $brokers
	 do
		wtbman -start -i "$broker"
	 done
	else
   for broker in $brokers
   do
    "$ganimedepath"/gnm_adm start "$broker"
   done
	fi
fi
